﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication2
{
    public partial class Rent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //When the page loads, the label indicating that the book is not available for rental is not shown.
            lblErrorMessage.Visible = false;

            //If there is no user ID saved in the session, it goes to the login error page.
            if (Session["username"] == null)
            {
                Response.Redirect("~/ErrorLogin");
            }
        }

        protected void Btnrent_Click(object sender, EventArgs e)
        {
            try
            {
                //When logging in, the user ID saved in the session is retrieved.
                String userID = null;
                userID = Convert.ToString(Session["username"]);

                //Connect to the database.
                String DBconnectionString = ConfigurationManager.ConnectionStrings["DataBaseConnectionString"].ConnectionString;
                SqlConnection sqlconn = new SqlConnection(DBconnectionString);
                sqlconn.Open();

                //Use the query to borrow the entered book and enter it in the check out log.
                SqlCommand sqlcomm = new SqlCommand();
                var queryString = "INSERT INTO CHECKOUT_LOG(User_ID, ISBN, Checkout_Date, Returned_Date) VALUES (@UserIDInput, @ISBNInput, GETDATE(), NULL)";
                sqlcomm.CommandText = queryString;
                sqlcomm.Connection = sqlconn;
                sqlcomm.Parameters.AddWithValue("@UserIDInput", userID);
                sqlcomm.Parameters.AddWithValue("@ISBNInput", Txtrent.Text);
                sqlcomm.ExecuteNonQuery();
                sqlconn.Close();

                //If the query is successful, it goes to the rental success page.
                Response.Redirect("~/RentalSuccess");
            }
            catch (SqlException)
            {
                //When an exception occurs due to a trigger that occurs to a book that has not been returned or a user who has not returned,
                //a label indicating that the rental is not allowed is displayed.
                lblErrorMessage.Visible = true;
            }
           
        }
    }
}