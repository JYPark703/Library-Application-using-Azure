﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication2
{
    public partial class SelectBookBySimliarityAzureSQL : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Btnsearch_Click(object sender, EventArgs e)
        {
            //Connect to the database.
            String DBconnectionString = ConfigurationManager.ConnectionStrings["DataBaseConnectionString"].ConnectionString;
            SqlConnection sqlconn = new SqlConnection(DBconnectionString);
            sqlconn.Open();

            //Use a query that displays book information related to the title or author that contains the entered data.
            SqlCommand sqlcomm = new SqlCommand();
            var queryString = "Select B.ISBN,B.Title,A.FName,A.LNAME From BOOKS as B inner join Author as A On B.Author_ID = A.Author_ID where B.title like '%'+@Input+'%' or A.FName like '%'+@Input+'%' or A.LName like '%'+@Input+'%'";
            sqlcomm.CommandText = queryString;
            sqlcomm.Connection = sqlconn;
            sqlcomm.Parameters.AddWithValue("Input", Txtsearch.Text);

            //Receive the result of the query through the DataSet.
            var dataAdaptor = new SqlDataAdapter(sqlcomm);
            var ds = new DataSet();
            dataAdaptor.Fill(ds);

            //The DataSet that received the result is displayed in GridView.
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();

        }
    }
}