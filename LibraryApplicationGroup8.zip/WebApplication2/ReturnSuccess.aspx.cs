﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication2
{
    public partial class ReturnSuccess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //When logging in, the user ID saved in the session is retrieved.
            String userID = null;
            userID = Convert.ToString(Session["username"]);
            LblUserDatails.Text = "USER ID: " + Session["username"];

            //Connect to the database.
            String DBconnectionString = ConfigurationManager.ConnectionStrings["DataBaseConnectionString"].ConnectionString;
            SqlConnection sqlconn = new SqlConnection(DBconnectionString);
            sqlconn.Open();

            //Use a query that calls the user's checkout log.
            SqlCommand sqlcomm = new SqlCommand();
            var queryString = "Select U.FName, U.LName,B.Title, FORMAT (L.Checkout_Date, 'yyyy/MM/dd'),FORMAT (L.Returned_Date, 'yyyy/MM/dd') From Checkout_Log as L inner Join Books as B on B.ISBN = L.ISBN inner join Library_USER as U On L.User_ID=U.User_ID where l.User_ID=@Input";
            sqlcomm.CommandText = queryString;
            sqlcomm.Connection = sqlconn;
            sqlcomm.Parameters.AddWithValue("Input", userID);

            //Receive the result of the query through the DataSet.
            var dataAdaptor = new SqlDataAdapter(sqlcomm);
            var ds = new DataSet();
            dataAdaptor.Fill(ds);

            //The DataSet that received the result is displayed in GridView.
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            //When you click the logout button, the session with the userID is discarded and you go to the default page.
            Session.Abandon();
            Response.Redirect("~/");
        }
    }
}