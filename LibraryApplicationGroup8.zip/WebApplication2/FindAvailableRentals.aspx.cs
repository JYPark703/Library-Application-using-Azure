﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication2
{
    public partial class FindAvailableRentals : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //When the page is loaded, the labels showing whether or not the rental is available are not shown.
            Label1.Visible = false;
            Label2.Visible = false;
        }

        protected void Btnsearch_Click(object sender, EventArgs e)
        {
            ////Connect to the database.
            String DBconnectionString = ConfigurationManager.ConnectionStrings["DataBaseConnectionString"].ConnectionString;
            SqlConnection sqlconn = new SqlConnection(DBconnectionString);
            sqlconn.Open();

            //If the entered book is a book that has not been returned, use a query showing the ISBN.
            SqlCommand sqlcomm = new SqlCommand();
            var queryString = "SELECT C. ISBN FROM Checkout_Log as C inner join books as B On C.ISBN = B.ISBN WHERE Returned_Date is null AND B.ISBN= @Input";
            sqlcomm.CommandText = queryString;
            sqlcomm.Connection = sqlconn;
            sqlcomm.Parameters.AddWithValue("Input", Txtsearch.Text);
            //Receive the result of the query through the DataSet.
            var dataAdaptor = new SqlDataAdapter(sqlcomm);
            var ds = new DataSet();
            dataAdaptor.Fill(ds);

            if (ds.Tables[0].Rows.Count == 0)
            {
                //If the DataSet is empty, a label indicating that rental is possible is displayed.
                Label1.Visible = true;
            }else
            {
                //If there is data in the DataSet, a label indicating that rental is not possible is displayed.
                Label2.Visible = true;
            }



        }

    }
}