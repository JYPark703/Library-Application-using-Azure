﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication2
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //When loading the page, do not show the label indicating if the ID and password are incorrect.
            lblErrorMessage.Visible = false;
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            ////Connect to the database.
            String DBconnectionString = ConfigurationManager.ConnectionStrings["DataBaseConnectionString"].ConnectionString;
            SqlConnection sqlconn = new SqlConnection(DBconnectionString);
            sqlconn.Open();

            //If there is a user with the same ID and password entered, use a query that returns 1.
            SqlCommand sqlcomm = new SqlCommand();
            var queryString = "SELECT COUNT(1) FROM LIBRARY_USER WHERE User_ID=@username AND User_PW=@password";
            sqlcomm.CommandText = queryString;
            sqlcomm.Connection = sqlconn;
            sqlcomm.Parameters.AddWithValue("@username", TxtUserName.Text.Trim());
            sqlcomm.Parameters.AddWithValue("@password", TxtPassword.Text.Trim());
            int count = Convert.ToInt32(sqlcomm.ExecuteScalar());


            if(count == 1)
            {
                //If the result is 1, the user ID is saved in the session and the page is displayed showing the checkout log.
                Session["username"] = TxtUserName.Text.Trim();
                Response.Redirect("~/Check_LogwithID");
            }
            else {
                //If 1 is not received as a result, a label indicating that the ID and password are incorrect is displayed.
                lblErrorMessage.Visible = true; 
            }
        }

    }
}